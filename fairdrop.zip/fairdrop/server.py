import flask
from flask import request, jsonify
import json
import os
import sys
import time
import flask_cors
import logging
import socket

def get_ip():
    print("[INFO] Trying to find your PC's IP address...")
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0)
    try:
        # doesn't even have to be reachable
        s.connect(('10.254.254.254', 1))
        IP = s.getsockname()[0]
        print("[INFO] FOUND IP: " + IP)
    except Exception:
        print("[INFO] Couldn't find your PC's IP address. Using localhost instead.")
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)
app = flask.Flask(__name__)

# Enable CORS
flask_cors.CORS(app)

app.static_folder = "static"


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    # get all files from the request
    files = request.files
    for key in files:
        # get the file from the request
        file = files[key]
        name = file.filename
        size = file.content_length
        size_mb = size / 1024 / 1024
        # if picture, save to ./saved/pictures
        # if video, save to ./saved/videos
        # if audio, save to ./saved/audios
        # if other, save to ./saved/other
        if file.content_type.startswith('image'):
            file.save(f'saved/pictures/{name}')
        elif file.content_type.startswith('video'):
            file.save(f'saved/videos/{name}')
        elif file.content_type.startswith('audio'):
            file.save(f'saved/audios/{name}')
        else:
            file.save(f'saved/other/{name}')
        print(f'[FILES] {name} saved. Size: {size_mb} MB')
    return {"status": "ok"}

@app.route("/")
def home():
    print(f"[INFO] Home page accessed")
    # return index.html
    return app.send_static_file('index.html')

@app.route('/<path:path>')
def static_file(path):
    # return all other static files
    return app.send_static_file(path)

config = open("configuration.json", "r")
config = json.load(config)
# check if host if null
if config["host"] == None:
    host = get_ip()
    # set in config
    config["host"] = host
    # save config
    with open("configuration.json", "w") as f:
        json.dump(config, f)
else:
    host = config["host"]

# check if port if null
if config["port"] == None:
    port = 80 # default port for http
    # set in config
    config["port"] = port
    with open("configuration.json", "w") as f:
        json.dump(config, f)
else:
    port = config["port"]

if port == 80:
    print(f"\n[INFO] VISIT > http://{host} < TO UPLOAD FILES")
else:
    print(f"\n[INFO] VISIT > http://{host}:{port} < TO UPLOAD FILES")
print()

app.run(host=host, port=port)