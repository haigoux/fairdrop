// create a new form object to store files
var form = new FormData();
var uploaded_files = 0;

function show_info_preview(state){
    // if state, add visible to #file-info-preview
    if(state){
        $('#file-info-preview').addClass('visible');
    }else{
        $('#file-info-preview').removeClass('visible');
    }
}

function show_upload_button(state){
    // if state, add visible to #upload-button
    if(state){
        $('#upload-btn-container').addClass('visible');
    }else{
        $('#upload-btn-container').removeClass('visible');
    }
}

function show_upload_button_stage(stage_name){
    // get all .stage elements
    var stages = $('.stage');
    // remove visible from all
    for(var i = 0; i < stages.length; i++){
        $(stages[i]).removeClass('visible');
    }
    // add visible to stage_name
    $(`#${stage_name}`).addClass('visible');
}

function show_pg_bar(state){
    // if state, add visible to #pg-bar
    if(state){
        $('#pg-bar').addClass('visible');
    }else{
        $('#pg-bar').removeClass('visible');
    }
}

function set_pg_fill(value){
    // set width of #pg-fill to value
    $('#pg-fill').css('width', value + '%');
}




function add_info_obj(key, value){
    // <div class="info">
    //     <span>key</span>
    //     <span>value</span>
    // </div>
    // add one of those to #info-container
    var values = []
    // create span with each value
    for(var i = 0; i < value.length; i++){
        values.push('<span>' + value[i] + '</span>');
    }
    var obj = $(`<div class="info">
                    <span>${key}</span>

    </div>`);
    // add each value to the object
    for(var i = 0; i < values.length; i++){
        obj.append(values[i]);
    }
    $('#info-container').append(obj);
}

$("#file-picker").on('click', function() {
    $("#file").click();
})

$("#file").on('change', function() {
    // add each file to the form object
    $.each(this.files, function(i, file) {
        form.append('file-'+i, file);
        uploaded_files++;
        show_info_preview(true);
        show_upload_button(true);
        var file_name = file.name;
        var file_type = file.type.split('/')[0];
        var file_size = file.size;
        var file_size_mb = file_size / 1000000;
        var file_size_mb_rounded = Math.round(file_size_mb * 100) / 100;
        add_info_obj(file_name, [file_type, file_size_mb_rounded + ' MB']);
    });
})

// on click of upload button
$('#upload-btn').on('click', function(){
    show_upload_button_stage('while-upload');
    // disable upload button
    $('#upload-btn').prop('disabled', true);
    // show progress bar
    show_pg_bar(true);
    var start_time = new Date().getTime();
    // upload files, use xhr to get progress and update progress bar
    $.ajax({
        url: 'upload',
        type: 'POST',
        data: form,
        processData: false,
        contentType: false,
        xhr: function() {
            var xhr = new window.XMLHttpRequest();
            xhr.upload.addEventListener("progress", function(evt) {
                if (evt.lengthComputable) {
                    var percentComplete = evt.loaded / evt.total;
                    percentComplete = parseInt(percentComplete * 100);
                    set_pg_fill(percentComplete);
                }
            }, false);
            return xhr;
        },
        success: function(data){
            var end_time = new Date().getTime();
            alert(`Uploaded ${uploaded_files} files in ${end_time - start_time}ms`);
            // relaod
            location.reload();
        }
    });
});
